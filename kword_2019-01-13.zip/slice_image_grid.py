import numpy as np
from matplotlib.image import imread, imsave
from PIL import Image
import cv2

"""
The trick is that each quadrant needs to be integer-sized (unlikely this will occur naturally), while maintaining proportionality. So we do some resizing and keep track of the changes in proportion:

1. Rotate/crop scanned image to align with character boundaries
 - . (period) character used for this purpose, bordering the charset:
 .........
 . A B C .
 . D E F .
 .........
  - image is cropped so that each surrounding period is cut in half
This is done manually, before running this script.

2. Resize UP cropped image (keeping proportion) to be evenly divisible by (number of characters in the X dimension * 2). The * 2 is because we will be chopping the characters into quadrants.
3. Resize in the y dimension (losing proportion) to be evenly divisible by (number of characters in the Y dimension * 2). Save (resizedY / originalY) as propChange.

4. Now the charset image can be evenly sliced into quadrants. The target image (ie. photograph of a face, etc) must be resized in the Y dimension by propChange before processing. Then, the output from processing (ie. the typed mockup) must also be resized by 1/propChange.

The issue of characters overextending their bounds cannot be fully addressed without substantial complication. We can pad the images during chopping, and then find a crop window (character size before padding) that maintains the most information from the padded images, ie. the sum of the cropped information is lowest across the character set.
"""

im = np.asarray(Image.open('hermes4.png'))

numX = 80  # Number of columns
numY = 8  # Number of rows

stepX = im.shape[1]/numX  # Slice width
stepY = im.shape[0]/numY  # Slice height

# Need to resize charset such that stepX and stepY are each multiples of 2
newStepX = int((stepX+4)//4) * 2 if not (im.shape[1] % numX == 0 and im.shape[1]//numX % 4 == 0) else stepX
newStepY = int((stepY+4)//4) * 2 if not (im.shape[0] % numY == 0 and im.shape[0]//numY % 4 == 0) else stepY

propChange = (stepX/stepY) / (newStepX/newStepY)

im = cv2.resize(im, dsize=(newStepX * numX, newStepY * numY), interpolation=cv2.INTER_AREA)

print("Actual character size", stepX, stepY)
print("Resized char size", newStepX, newStepY)
print("Y stretch factor", propChange)


startX = int(0.62*newStepX)  # Crop left px
startY = int(0.26*newStepY)  # Crop top px

xPad = 5
yPad = 5

whiteThreshold = 0.95 # Don't save images that are virtually empty

tiles = [np.array(im[y-yPad:y+newStepY+yPad, x-xPad:x+newStepX+xPad][:,:,1], dtype='uint8')
         for x in range(startX, im.shape[1], newStepX)
         for y in range(startY, im.shape[0], newStepY)
         # Set some threshold so that the blank spaces will not be saved
         if np.sum(im[y:y+newStepY, x:x+newStepX][:,:,1]) < (newStepX*newStepY*whiteThreshold*255)
           and y+newStepY < im.shape[0] and x+newStepX < im.shape[1]]

shrink = 2 # Should be a common multiple of stepX and stepY. Reduce size
# smTiles = []
for i, tile in enumerate(tiles):
    imsave(f'out/tile-{i}.png', tile, cmap='Greys_r')
    # smTiles.append(tile)

# Append blank tile
tiles.append(np.full((newStepY+yPad*2, newStepX+xPad*2), 255, dtype='uint8'))
    
print(len(tiles), 'images saved.')

# Save the numpy vectors to a file (to be used in gen_combos, etc)
np.save('sliced_chars.npy', np.array(tiles))