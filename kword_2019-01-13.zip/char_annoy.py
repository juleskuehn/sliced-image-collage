# # TensorFlow and tf.keras
# import tensorflow as tf
# from tensorflow import keras

# Helper libraries
import numpy as np
import matplotlib.pyplot as plt
import math
import random
from timeit import Timer

# Approximate Nearest Neighbour
from annoy import AnnoyIndex

# print(tf.__version__)

# Build annoy model from chars
def buildModel(chars, trees=10):

  t = AnnoyIndex(dim) # Number of pixels

  # Add training images
  # Indices match input list
  for i, char in enumerate(chars):
    t.add_item(i, np.ndarray.flatten(char))

  t.build(trees)
  t.save('charset.ann')
    
chars = list(np.load('cropped_chars.npy'))
dim = chars[0].shape[0] * chars[0].shape[1]

buildModel(chars, 10)

# Returns indices of num_neighbours nearest neighbours to index (including self)
def testModel(index, num_neighbours):
    u = AnnoyIndex(dim)
    u.load('charset.ann') # mmap the file
    return u.get_nns_by_item(index, num_neighbours)

print(testModel(0, 10))

def testModelV(v, num_neighbours):
  u = AnnoyIndex(dim)
  u.load('charset.ann')
  return u.get_nns_by_vector(v, num_neighbours)

v = np.random.rand(dim) * 255
print(testModelV(v, 10))


# Plot n nearest neighbours to image at index idx in model in a grid
# First image is the input image
def showNearestV(v, n):
  w = math.ceil(math.sqrt(n))
  plt.figure(figsize=(w*2, w*2))
  j = 0
  for i in testModelV(v, n):
    plt.subplot(w, w, j+1)
    j += 1
    plt.xticks([])
    plt.yticks([])
    plt.grid(False)
    print(i)
    plt.imshow(chars[i], cmap='Greys_r')
#     color = 'blue' if getLabel(idx) == getLabel(i) else 'red'
#     if i == idx: color = 'green'
#     label = class_names[getLabel(i)] + ": " + str(i)
    
#     plt.xlabel(label, color=color)
  plt.show()
    
# showNearestV((np.random.rand(dim) * 255).astype('uint8'), 16)

# Plot n nearest neighbours to image at index idx in model in a grid
# First image is the input image
def showNearest(idx, n):
  w = math.ceil(math.sqrt(n))
  plt.figure(figsize=(w*2, w*2))
  j = 0
  for i in testModel(idx, n):
    plt.subplot(w, w, j+1)
    j += 1
    plt.xticks([])
    plt.yticks([])
    plt.grid(False)
    plt.imshow(chars[i], cmap='Greys_r')
  plt.show()
    # color = 'blue' if getLabel(idx) == getLabel(i) else 'red'
    # if i == idx: color = 'green'
    # label = class_names[getLabel(i)] + ": " + str(i)
    
    # plt.xlabel(label, color=color)
    
showNearest(random.randint(0,len(chars)), 16)