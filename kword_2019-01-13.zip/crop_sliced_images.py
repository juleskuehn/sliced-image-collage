import numpy as np
from matplotlib.image import imread, imsave
from PIL import Image
import cv2
from math import inf

a = np.load('sliced_chars.npy')

# Padding present on the input images
xPad = 5
yPad = 5

maxCroppedOut = -inf
maxCropXY = (0, 0) # Top left corner of crop window

ySize, xSize = a[0].shape
ySize -= yPad * 2 # Target crop
xSize -= xPad * 2 # Target crop

# Try all the crops and find the best one (the one with most white)
for y in range(yPad * 2):
    for x in range(xPad * 2):
        croppedOut = np.sum(a) - np.sum(a[:,y:y+ySize,x:x+xSize])
        if croppedOut > maxCroppedOut:
            maxCroppedOut = croppedOut
            maxCropXY = (x, y)

print(maxCropXY)

x, y = maxCropXY
np.save('cropped_chars.npy', a[:,y:y+ySize,x:x+xSize])