import numpy as np
from matplotlib import pyplot as plt
from matplotlib.image import imread, imsave
from PIL import Image
import cv2
from blend_modes import blend_modes

a = list(np.load('cropped_chars.npy'))

# Takes a list of 2d numpy arrays (members of 'a', above) to blend
# Input length must be at least 1
# Input and output images both uint8
def blendImages(imgs):
    opacity = 1
    j = imgs[0]
    img = np.array([[[imgs[0][y, x], imgs[0][y, x], imgs[0][y, x], 255] for x in range(imgs[0].shape[1])] for y in range(imgs[0].shape[0])], dtype='float')
    for im in imgs[1:]:
        rgbaImg2 = np.array([[[im[y, x], im[y, x], im[y, x], 255] for x in range(imgs[0].shape[1])] for y in range(imgs[0].shape[0])], dtype='float')
        # Blend images
        img = blend_modes.multiply(img, rgbaImg2, opacity)
    return img

# Create combination of x, y grid of characters
# Input is 2d list of 2d numpy arrays, in order of grid positions
# We assume that the images have even dimensions
def gridCombo(imgs):
    ySize, xSize = imgs[0][0].shape
    yOutSize = (len(imgs) + 1) * ySize//2
    xOutSize = (len(imgs[0]) + 1) * xSize//2
    paddedImgs = []
    # Pad all the images to create the overlap
    for y in range(len(imgs)):
        offsetY = y * ySize//2
        for x in range(len(imgs[y])):
            offsetX = x * xSize//2
            pImg = np.full((yOutSize, xOutSize), 255, dtype='uint8')
            pImg[offsetY:offsetY+ySize, offsetX:offsetX+xSize] = imgs[y][x]
            paddedImgs.append(pImg)
    
    return blendImages(paddedImgs)

# img = gridCombo([
#     [a[i] for i in range(0,20)],
#     [a[i] for i in range(20,40)],
#     [a[i] for i in range(40,60)],
#     [a[i] for i in range(60,80)],
#     [a[i] for i in range(80,86)]
#     ])

# img = gridCombo([[a[18]]])

# img = gridCombo([
#     [a[18]] * 16
#     for j in range(8)
# ])

# img = gridCombo([
#     [a[18], a[19]] * 3,
#     [a[16], a[17]] *
#     ] * 3)

# img = gridCombo([ [a[19]] * 2 ] * 2)

# img = cv2.resize(img, dsize=(a[0].shape[0] // 2, a[0].shape[1] // 2), interpolation=cv2.INTER_CUBIC)
# Display blended image
# plt.imshow(img.astype('float')[:,:,0], cmap = 'gray', interpolation = 'bicubic')
# plt.show()

grid = [ [a[(j+i*10)//2] if j % 2 == 0 and i % 2 == 0 else a[-1] for j in range(19)] for i in range(15)]

img = gridCombo(grid)
print(img.shape)
imsave(f'testGrid.png', img.astype('float')[:,:,0], cmap='Greys_r')
