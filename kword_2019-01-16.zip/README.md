# sliced-image-collage
